<?php

// force UTF-8 Ø

echo gettext("Zenpage theme designed by <a href=\"http://www.maltem.de\">Malte Müller</a>");
?> | <?php printZenphotoLink(); ?>