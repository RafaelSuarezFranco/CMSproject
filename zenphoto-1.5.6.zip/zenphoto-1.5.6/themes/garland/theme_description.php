<?php

// force UTF-8 Ø

// Zenphoto theme definition file
$theme_description['name'] = 'Garland';
$theme_description['author'] = 'Mark Galeassi (aitf311) updated by Stephen Billard (sbillard) and Malte Müller (acrylian)';
$theme_description['version'] = true;
$theme_description['date'] = true;
$theme_description['desc'] = gettext('Modded Wordpress theme from, <a href="http://garlandtheme.blogspot.com/">garland</a>');
?>