<?php define('ZENPHOTO_VERSION', '1.5.6');
